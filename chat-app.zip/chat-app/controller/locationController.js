const { generateLocationMessage } = require("../controller/MessageController");
const { getUser } = require("../src/utils/users");

exports.generateLocation = (io, socket, coords, callback) => {
  const user = getUser(socket.id);
  if (!user) {
    return callback("user not found");
  }
  io.to(user.room).emit(
    "locationMessage",
    generateLocationMessage(
      user.username,
      `https://google.com/maps?q=${coords.latitude},${coords.longitude}`
    )
  );
  callback();
};
