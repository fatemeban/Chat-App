const { generateAudioMessage } = require("../src/utils/messages");
const { getUser } = require("../src/utils/users");

const audioController = (io, socket) => {
  socket.on("audioStream", (audioData, callback) => {
    const user = getUser(socket.id);
    if (!user) {
      return callback("User not found");
    }

    io.to(user.room).emit(
      "audioStream",
      generateAudioMessage(user.username, audioData)
    );

    if (callback) {
      callback();
    }
  });
};

module.exports = audioController;
