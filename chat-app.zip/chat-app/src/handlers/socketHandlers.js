const { Server } = require("socket.io");
const locationController = require("../../controller/locationController");
const userController = require("../../controller/usercontroller");
const audioController = require("../../controller/audioController");
const messageController = require("../../controller/MessageController"); // Add this line

const socketHandler = (server) => {
  //const io = require("socket.io")(server);
  const io = new Server(server);

  io.on("connection", (socket) => {
    console.log("New WebSocket connection");

    userController(io, socket);
    messageController(io, socket);
    audioController(io, socket);
    locationController(io, socket);
  });
};

module.exports = socketHandler;
