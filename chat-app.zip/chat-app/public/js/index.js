const path = require("path");
const http = require("http");
const express = require("express");
const multer = require("multer");
const socketio = require("socket.io");

const socketHandler = require("../../src/handlers/socketHandlers");
const uploadRouter = require("../../router/upload");

const app = express();
const server = http.createServer(app);
const io = socketio(server);

const port = process.env.PORT || 3003;
const publicDirectoryPath = path.join(__dirname, "../public");

////middlewere////
app.use(express.static(publicDirectoryPath));
app.use(express.json());
app.set("io", io);

// Multer setup for file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage });

app.get("/", (req, res) => {
  res.send("Welcome to the homepage!");
});

socketHandler(server);

////Routes
app.use("/upload", uploadRouter);

server.listen(port, () => {
  console.log(`Server is up on port ${port}!`);
});
