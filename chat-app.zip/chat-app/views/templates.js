export const messageTemplate =
  document.querySelector("#message-template").innerHTML;
export const locationMessageTemplate = document.querySelector(
  "#location-message-template"
).innerHTML;
export const sidebarTemplate =
  document.querySelector("#sidebar-template").innerHTML;
export const pictureMessageTemplate = document.querySelector(
  "#picture-message-template"
).innerHTML;
export const voiceMessageTemplate = document.querySelector(
  "#voice-message-template"
).innerHTML;

// // Templates
// const messageTemplate = document.querySelector("#message-template").innerHTML;
// const locationMessageTemplate = document.querySelector(
//   "#location-message-template"
// ).innerHTML;
// const sidebarTemplate = document.querySelector("#sidebar-template").innerHTML;
// const pictureMessageTemplate = document.querySelector(
//   "#picture-message-template"
// ).innerHTML;
// const voiceMessageTemplate = document.querySelector(
//   "#voice-message-template"
// ).innerHTML;
