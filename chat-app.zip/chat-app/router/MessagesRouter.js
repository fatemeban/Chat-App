import { Router } from "express";
import multer from "multer";
import { gerMessage } from "";
import { uploadFile } from "../../controller/Messagecontroller";

const messageRouters = Router();
const upload = multer({ dest: "uploads/files" });

messageRouters.post("/upload-file", upload.single("file"), uploadFile);

export default messageRouters;
